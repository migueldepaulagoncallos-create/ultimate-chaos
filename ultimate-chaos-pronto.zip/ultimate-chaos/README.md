# Ultimate Chaos — jogo multiplayer 3D

Projeto web jogável com Three.js no navegador e servidor Node.js + Socket.IO. Inclui cinco arenas/mapas, salas públicas e privadas por código, matchmaking rápido, até 20 jogadores por sala, personagens personalizáveis, loja local de skins, teclado e controles de toque.

## Requisitos
- Node.js 18 ou mais recente
- Conexão com a internet para carregar Three.js pelo CDN na primeira abertura

## Executar no computador
1. Extraia o ZIP.
2. Abra um terminal dentro da pasta `ultimate-chaos` (a pasta que contém `package.json`).
3. Execute `npm install`.
4. Execute `npm start`.
5. Abra `http://localhost:3000` no navegador.

Para testar com celulares/computadores na mesma rede Wi-Fi, abra `http://IP-DO-COMPUTADOR:3000` nos outros dispositivos. O firewall do computador precisa permitir conexões na porta 3000.

## Publicar na internet (Render)
1. Envie o conteúdo desta pasta para um repositório GitHub.
2. No Render, crie um **Web Service** e conecte o repositório.
3. Configure **Build Command** como `npm install` e **Start Command** como `npm start`.
4. Depois do deploy, abra a URL HTTPS gerada e compartilhe-a com os jogadores.

O servidor usa `process.env.PORT`, escuta em `0.0.0.0` e oferece `/health` para verificação de disponibilidade. Também pode ser hospedado em Railway ou VPS Node.js.

## Como jogar
- **PC:** WASD ou setas para andar; Espaço para pular; Shift para correr; E/F para agarrar; Q para comemorar. Arraste o mouse para girar a câmera.
- **Celular:** joystick à esquerda; botões PULAR, CORRER, AGARRAR e EMOTE à direita. Arraste a tela para controlar a câmera.
- **JOGAR:** entra no matchmaking automático. Salas públicas iniciam após reunir pelo menos dois jogadores.
- **CRIAR SALA:** cria uma sala privada com código de quatro letras. Compartilhe o código; o anfitrião inicia quando houver pelo menos dois jogadores.
- **MULTIPLAYER:** permite consultar salas públicas e entrar usando código.

## Observações técnicas
- O servidor controla salas, início/fim de rodadas, classificação, eliminações e valida limites básicos de velocidade/posição recebida.
- A movimentação e a física detalhada ainda são calculadas no navegador; portanto, esta versão é um protótipo multiplayer funcional, não um sistema competitivo com física integralmente autoritativa no servidor ou proteção avançada contra trapaças.
- Moedas e compras de skins são salvas no armazenamento local do navegador, não em uma conta online.
- Para partidas em internet pública, recomenda-se adicionar persistência de contas, validação de colisões/física no servidor, limites de requisição e testes de carga antes de escalar.
