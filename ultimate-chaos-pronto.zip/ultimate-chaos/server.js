const express = require('express'), http = require('http'), { Server } = require('socket.io');
const app = express(); app.use(express.static(__dirname + '/public'));
const srv = http.createServer(app), io = new Server(srv);
const MAPS = [
  { n: 'Corrida de Obstáculos', fz: -118 }, { n: 'Plataforma Giratória', fz: -100 },
  { n: 'Ponte de Plataformas', fz: -112 }, { n: 'Pista Escorregadia', fz: -120 },
  { n: 'Arena de Sobrevivência', arena: 1 }];
const rooms = new Map(), L = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const gen = () => { let c; do c = [...Array(4)].map(() => L[Math.random() * L.length | 0]).join(''); while (rooms.has(c)); return c; };
const mk = auto => { const r = { code: gen(), players: new Map(), host: null, state: 'lobby', auto, autoAt: 0, out: [], n: 0 }; rooms.set(r.code, r); return r; };
const info = r => ({ code: r.code, host: r.host, state: r.state, autoAt: r.autoAt, players: [...r.players.values()].map(p => ({ id: p.id, name: p.name, skin: p.skin })) });
const emitRoom = r => io.to(r.code).emit('room', info(r));
const alive = r => [...r.players.values()].filter(p => p.alive);
const shuffle = a => a.sort(() => Math.random() - .5);

function leave(s) {
  const r = rooms.get(s.room); if (!r) { s.room = null; return; }
  const leaving = r.players.get(s.id);
  if (leaving) leaving.alive = false;
  r.players.delete(s.id); s.leave(r.code); s.room = null;
  if (!r.players.size) return rooms.delete(r.code);
  if (r.host === s.id) r.host = r.players.keys().next().value;
  emitRoom(r);
}
function join(s, r, d) {
  if (!r) return s.emit('err', 'Sala não encontrada');
  if (r.state !== 'lobby') return s.emit('err', 'Partida em andamento');
  if (r.players.size >= 20) return s.emit('err', 'Sala cheia (20/20)');
  leave(s); s.join(r.code); s.room = r.code;
  r.players.set(s.id, { id: s.id, name: String(d.name || 'Jogador').slice(0, 12), skin: d.skin || {}, alive: true, x: 0, y: 1, z: 0, t: Date.now() });
  if (!r.host) r.host = s.id;
  emitRoom(r);
}
function startGame(r) {
  r.out = []; r.n = 0; r.maps = shuffle([0, 1, 2, 3]);
  r.players.forEach(p => p.alive = true);
  nextRound(r);
}
function nextRound(r, arena) {
  const al = alive(r);
  if (!al.length) return resetLobby(r);
  r.cur = arena ? 4 : r.maps[r.n++]; r.a0 = al.length; r.fin = 0; r.fe = 0;
  const sp = {};
  al.forEach((p, i) => {
    p.fin = 0; p.t = Date.now();
    if (arena) { const a = i / al.length * 6.283; p.x = Math.cos(a) * 12; p.z = Math.sin(a) * 12; p.y = .5; }
    else { p.x = ((i % 10) - 4.5) * 1.5; p.z = 8 - (i / 10 | 0) * 2; p.y = .5; }
    sp[p.id] = [p.x, p.y, p.z];
  });
  r.state = 'cd'; r.start = Date.now() + 4500; r.end = r.start + (arena ? 60000 : 80000);
  io.to(r.code).emit('round', { map: r.cur, name: MAPS[r.cur].n, now: Date.now(), startAt: r.start, dur: (r.end - r.start) / 1000, sp, n: r.n });
}
function endRound(r) {
  const al = alive(r).sort((a, b) => (a.fin || 99) - (b.fin || 99) || a.z - b.z);
  const k = r.a0 > 3 ? Math.floor(r.a0 / 2) : 0, out = al.slice(al.length - k);
  out.forEach(p => { p.alive = false; r.out.push(p.id); });
  const left = al.length - k; r.state = 'wait';
  io.to(r.code).emit('roundEnd', { out: out.map(p => p.id), left });
  setTimeout(() => { if (rooms.has(r.code)) (left > 3 && r.n < 4) ? nextRound(r) : nextRound(r, 1); }, 4000);
}
function win(r, al) {
  r.state = 'ended';
  const w = al.sort((a, b) => Math.hypot(a.x, a.z) - Math.hypot(b.x, b.z))[0];
  const ranking = [...(w ? [w.id] : []), ...al.filter(p => p !== w).map(p => p.id), ...[...r.out].reverse()];
  io.to(r.code).emit('winner', { id: w && w.id, ranking });
  setTimeout(() => resetLobby(r), 12000);
}
function resetLobby(r) { if (!rooms.has(r.code)) return; r.state = 'lobby'; r.autoAt = 0; r.players.forEach(p => p.alive = true); emitRoom(r); }

io.on('connection', s => {
  s.on('quick', d => {
    const r = [...rooms.values()].find(r => r.auto && r.state === 'lobby' && r.players.size < 20) || mk(true);
    join(s, r, d || {});
  });
  s.on('create', d => join(s, mk(false), d || {}));
  s.on('join', d => join(s, rooms.get(String(d && d.code || '').toUpperCase().trim()), d));
  s.on('list', cb => typeof cb === 'function' && cb([...rooms.values()].filter(r => r.auto && r.state === 'lobby').map(r => ({ code: r.code, n: r.players.size }))));
  s.on('start', () => { const r = rooms.get(s.room); if (r && r.host === s.id && r.state === 'lobby') { if (r.players.size < 2) return s.emit('err', 'São necessários pelo menos 2 jogadores para iniciar.'); r.autoAt = 0; startGame(r); } });
  s.on('leave', () => leave(s));
  s.on('emote', e => { if (s.room) s.to(s.room).emit('emote', { id: s.id, e: Math.max(0, Math.min(2, Number(e) | 0)) }); });
  s.on('grab', d => { const r = rooms.get(s.room); if (r && r.state === 'play' && d && r.players.has(d.to) && r.players.get(d.to).alive) io.to(d.to).emit('grabbed', { by: s.id }); });
  s.on('mv', d => {
    const r = rooms.get(s.room), p = r && r.players.get(s.id);
    if (!p || !p.alive || r.state !== 'play' || !d) return;
    if (![d.x, d.y, d.z, d.r].every(Number.isFinite)) return;
    const dt = Math.min((Date.now() - p.t) / 1000, 1); p.t = Date.now();
    if (Math.hypot(d.x - p.x, d.z - p.z) > 22 * dt + 4) return s.emit('fix', { x: p.x, y: p.y, z: p.z });
    Object.assign(p, { x: d.x, y: d.y, z: d.z, r: d.r, a: d.a | 0 });
    const m = MAPS[r.cur];
    if (m.fz && !p.fin && p.z < m.fz) { p.fin = ++r.fin; io.to(r.code).emit('fin', { id: p.id, place: p.fin }); }
    if (m.arena && p.y < -12) { p.alive = false; r.out.push(p.id); io.to(r.code).emit('elim', { id: p.id, left: alive(r).length }); }
  });
  s.on('disconnect', () => leave(s));
});

setInterval(() => {
  const now = Date.now();
  for (const r of rooms.values()) {
    if (r.state === 'lobby') {
      if (r.auto && r.players.size >= 2) {
        if (!r.autoAt) { r.autoAt = now + 10000; emitRoom(r); }
        else if (now >= r.autoAt) { r.autoAt = 0; startGame(r); }
      } else if (r.autoAt) { r.autoAt = 0; emitRoom(r); }
      continue;
    }
    if (r.state !== 'cd' && r.state !== 'play') continue;
    const al = alive(r);
    io.to(r.code).volatile.emit('snap', al.map(p => [p.id, +p.x.toFixed(2), +p.y.toFixed(2), +p.z.toFixed(2), +(p.r || 0).toFixed(2), p.a | 0]));
    if (r.state === 'cd') { if (now >= r.start) r.state = 'play'; continue; }
    const m = MAPS[r.cur];
    if (m.arena) { if ((r.a0 > 1 && al.length <= 1) || now > r.end || !al.length) win(r, al); }
    else {
      const need = r.a0 > 3 ? Math.ceil(r.a0 / 2) : r.a0;
      if (r.fin >= need && !r.fe) r.fe = now + 3000;
      if ((r.fe && now >= r.fe) || now > r.end || !al.length || al.every(p => p.fin)) endRound(r);
    }
  }
}, 50);

app.get('/health', (_req, res) => res.json({ ok: true, game: 'Ultimate Chaos', rooms: rooms.size }));
const PORT = process.env.PORT || 3000;
srv.listen(PORT, '0.0.0.0', () => console.log('Ultimate Chaos rodando na porta ' + PORT));
process.on('SIGTERM', () => srv.close(() => process.exit(0)));
process.on('SIGINT', () => srv.close(() => process.exit(0)));
